# Remote Touch — Windows public pilot

1. Extract this ZIP completely.
2. Open Start.cmd. On first launch it downloads and verifies the official Node.js runtime automatically (Internet required, about 35 MB). Then click Start and keep the app open.
3. On your phone or another computer open https://remote-touch.onrender.com
4. Enter the Computer ID and temporary Access code shown by the Windows app.
5. Click Approve on the Windows computer.

No certificate installation or router setup is required. The Windows app must remain open and the computer awake. Use STOP / DISCONNECT to end access.

This is an unsigned pilot, not a production release. The free service may take about a minute to wake and device IDs may change after a server restart. Audio, lock screen/UAC control and unattended access are unavailable. The relay terminates HTTPS; sessions are not end-to-end encrypted.
