$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$base = [IO.Path]::GetFullPath($PSScriptRoot)
$runtime = Join-Path $base 'runtime'
$nodeFile = Join-Path $runtime 'node.exe'
if (Test-Path -LiteralPath $nodeFile) { exit 0 }
$archivePath = Join-Path $base 'node-runtime-download.zip'
try {
  Write-Host 'Preparing Remote Touch (first launch only)...'
  Write-Host 'Downloading the official Node.js runtime. Please wait.'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://nodejs.org/dist/v24.21.0/node-v24.21.0-win-x64.zip' -OutFile $archivePath
  $actual = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne '158f7685b44de51f6c0df1d153526cbcd3e1bc739a8dfc607721cef75de9e541') { throw 'Runtime checksum mismatch. Download rejected.' }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Directory]::CreateDirectory($runtime) | Out-Null
  $archive = [IO.Compression.ZipFile]::OpenRead($archivePath)
  try {
    foreach ($name in @('node.exe','LICENSE')) {
      $entry = $archive.GetEntry('node-v24.21.0-win-x64/' + $name)
      if ($null -eq $entry) { throw 'Official runtime archive is missing a required file.' }
      [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,(Join-Path $runtime $name),$true)
    }
  } finally { $archive.Dispose() }
  Write-Host 'Ready. Opening Remote Touch.'
} catch {
  Write-Host ('Setup failed: ' + $_.Exception.Message)
  Write-Host 'Check your internet connection, then open Start.cmd again.'
  exit 1
} finally {
  if (Test-Path -LiteralPath $archivePath) { Remove-Item -LiteralPath $archivePath -Force }
}
