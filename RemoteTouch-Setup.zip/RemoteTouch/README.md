# Remote Touch 0.4 — public-service pilot

An English browser client and a real Windows desktop host. Includes native screen capture, mouse and Unicode keyboard input, touch controls, approval, and an outbound company relay transport.

**Status:** public pilot deployed at https://remote-touch.onrender.com. Windows pilot download: https://github.com/neamat-web/remote-touch-downloads. See docs/DEPLOYMENT-REPORT.md for tested scope and limitations.

## Download-and-connect experience

Download the configured Windows app → Start → receive a Computer ID automatically → open its link on any device → enter the access code → approve on Windows. Different Internet networks are supported by the relay design. No phone certificate import or per-user administrator configuration is needed after deployment.

- [Quick start](QUICKSTART.md)
- [Public service, automatic registration and current verification](docs/PUBLIC-SERVICE.md)
- [Company installation, GitHub Pages, costs and limitations](docs/COMPANY-DEPLOYMENT.md)
- [Current verification report](docs/TEST-REPORT-0.3.md)
- [Detailed validation checklist](docs/VALIDATION.md)

## Build and run

Windows 11 x64 with .NET Framework 4.8 and Node.js 22 or newer:

~~~powershell
npm test
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build.ps1
.\Start.cmd
~~~

To bundle Node so employees do not install it separately, use an official Node Windows ZIP distribution on PATH, with its LICENSE beside node.exe:

~~~powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package-company.ps1
~~~

GitHub Actions builds the same Windows package. For the public service, set RT_RELAY_URL in the build workflow once; every download gets the common service address and generates its own protected identity. No per-user .env is needed. For optional managed enrollment, use the company deployment guide.

For a local developer connection, Start defaults to loopback. The LAN checkbox enables private LAN access; that legacy mode still needs a certificate trusted by the controller. For easy employee access, use company mode as described in the deployment guide.

## Project structure

| Directory | Purpose |
| --- | --- |
| host | C# WinForms, native capture/input, approval and certificate generation |
| web | Responsive English browser client |
| server | Host-side authenticated API and outbound bridge |
| relay | Company relay, reverse proxy and Linux service configuration |
| scripts | Build, packaging, device registration and website build |
| tests | Coordinates, access controls and relay transport tests |
| .github/workflows | Windows build and optional Pages publishing |

## Implemented boundaries

Windows user-session capture and SendInput are real. The relay uses HTTPS JPEG frames, not WebRTC; performance needs a WAN pilot. Audio, unattended access, SSO/MFA, a fleet dashboard, centralized audit logging, signed installer and automatic updates are not implemented. UAC secure desktop, lock/logon screens and sleeping/offline PCs cannot be controlled. Every successful connection still needs host approval.

No persistent remote access starts automatically. The red stop button, app closure and Windows locking stop sharing. Clipboard and files require additional explicit host consent.

All remote traffic passes through the company relay, which terminates TLS and can access content. There is no end-to-end encryption claim.

Historical architecture and test reports for 0.2 are retained under docs; the 0.3 report and company deployment guide describe current behavior.


## Small public download

After building the Windows host, run `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/package-public.ps1`. The output `RemoteTouch-Setup.zip` downloads and verifies a pinned official Node.js runtime on first launch. GitHub Actions also produces this ZIP. Never include `.data` or personal `.env` files in a release.
