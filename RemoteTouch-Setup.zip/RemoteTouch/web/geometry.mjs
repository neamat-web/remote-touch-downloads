export function remotePoint(clientX,clientY,rect) {
  if (!rect.width || !rect.height || clientX<rect.left || clientY<rect.top || clientX>rect.left+rect.width || clientY>rect.top+rect.height) return null;
  return {x: Math.min(1,Math.max(0,(clientX-rect.left)/rect.width)), y:Math.min(1,Math.max(0,(clientY-rect.top)/rect.height))};
}
export function zoomAt(oldScale, newScale, offset, point) {
  return point - (point-offset) * newScale/oldScale;
}
