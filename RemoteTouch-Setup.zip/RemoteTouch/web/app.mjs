import {remotePoint,zoomAt} from './geometry.mjs';
const $=id=>document.getElementById(id);
const messages={
en:{offline:'Not connected',private:'PRIVATE CONNECTION · WINDOWS 11',headline:'Your desktop.\nWithin reach.',intro:'Use your phone, tablet, or another computer to work on your Windows desktop. Every session starts with your approval.',feature1:'Touch that feels natural',feature1desc:'Direct touch or a precision touchpad.',feature2:'Your screen, securely',feature2desc:'Encrypted traffic. A visible host. An instant stop.',previewNote:'Remote support with your permission',connectTitle:'Connect to a computer',codeHelp:'Enter the 8-digit code shown in Remote Touch on your Windows computer.',deviceLabel:"This device’s name",codeLabel:'Access code',useTrust:"Use this browser’s saved device identity",connectButton:'Connect →',secureNote:'The Windows host must approve before any screen or input is shared. Codes expire after 2 minutes.',forget:'Forget this device',disconnect:'Disconnect',loading:'Waiting for the first live frame…',toolbar:'Controls ▾',direct:'Direct touch',touchpad:'Touchpad',viewMode:'View / zoom',left:'Left click',right:'Right click',drag:'Drag lock',keyboard:'Keyboard',fit:'Fit',actual:'1:1',fullscreen:'Fullscreen',settings:'Settings',sendText:'Send text',typeHere:'Type Arabic or English, then send',monitor:'Monitor',refresh:'Refresh',resolution:'Maximum stream width',quality:'JPEG quality',fps:'Frame-rate limit',adaptive:'Adapt to connection',sensitivity:'Touchpad sensitivity',audio:'System audio',audioNote:'Not available in this release. No sound is captured.',clipboard:'Clipboard text',clipboardHelp:'Enable clipboard in the host window first. Sharing is manual.',clipboardGet:'Read host clipboard',clipboardSet:'Send to host clipboard',files:'File transfer',fileHelp:'Up to 100 MiB. The host approves uploads and chooses download files.',download:'Ask host for a file',cancel:'Cancel transfer',footer:'Local first. No unattended access. Your host stays in control.',pending:'Waiting for approval on the Windows host…',connected:'Connected · encrypted',reconnecting:'Connection interrupted. Retrying…',ended:'Session ended. Connect again.',directHint:'Tap to click · Slide to drag · Two-finger tap: right click · Two-finger swipe: scroll. Use View / zoom to pinch and pan.',touchpadHint:'Slide to move · Tap to click · Two-finger tap: right click · Two-finger swipe: scroll · Double-tap and hold to drag.',viewHint:'Viewing only: pinch to zoom, drag to pan. Switch to Direct touch or Touchpad to control.',paused:'Input released. Return to the desktop to continue.',fullUnsupported:'Fullscreen is not supported here. Use landscape orientation.',transferring:'Transferring…',complete:'Transfer complete',cancelled:'Transfer cancelled',saved:'Saved on the host',waitingFile:'Waiting for the host to approve or select a file…',clipboardReady:'Clipboard sharing is enabled on the host.',clipboardOff:'Clipboard sharing is disabled on the host.',network:'Cannot reach the host. Check that it is running and both devices are on the same private network.',decode:'Could not decode desktop frame.',typingSent:'Text sent to the focused application on the host.'},
};
const storage={get:k=>{try{return localStorage.getItem(k);}catch{return null;}},set:(k,v)=>{try{localStorage.setItem(k,v);}catch{}},remove:k=>{try{localStorage.removeItem(k);}catch{}}};
const lang='en';
const t=k=>messages[lang][k]||k;
let configuration={mode:'company',relayUrl:''};
try{const r=await fetch(new URL('./config.json',location.href),{cache:'no-store'});if(!r.ok)throw Error();configuration=await r.json();}catch{}
const company=configuration.mode==='company';
let apiBase='',hostId=new URLSearchParams(location.search).get('host')||'';
if(company&&configuration.relayUrl){const u=new URL(configuration.relayUrl);if(u.protocol==='https:'&&!u.username&&!u.password&&u.pathname==='/'&&!u.search&&!u.hash)apiBase=u.origin;}
const configured=!company||!!apiBase;
let deviceStorageKey='rt-device:'+apiBase+':'+hostId;
$('computerField').hidden=!company||!!hostId;$('computerId').value=hostId;$('computerId').required=company;
if(!configured){$('pairButton').disabled=true;$('pairMessage').textContent='The Remote Touch connection service is not online yet. Please try again after the service launches.';}
if(company){messages.en.private='REMOTE TOUCH · ANYWHERE';messages.en.footer='Every session requires approval on the computer.';messages.en.network='Cannot reach Remote Touch. Check your Internet connection and try again.';}
function selectComputer(){hostId=$('computerId').value.trim();deviceStorageKey='rt-device:'+apiBase+':'+hostId;$('useTrust').checked=false;$('useTrust').disabled=!storage.get(deviceStorageKey);$('pairCode').required=true;$('pairCode').disabled=false;}
$('computerId').onchange=selectComputer;
let authToken=null,mode='direct',monitors=[],monitor=0,seq=0,epoch=0,releasing=0,queue=[],sending=false,dragLock=false,firstFrame=true;
let scale=1,offsetX=0,offsetY=0,fitMode=true,sourceWidth=1600,sourceHeight=900,frameGeneration=0;
let quality=65,width=1600,rtt=0,frames=0,lastMetrics=performance.now(),renderFps=0,lastGood=0,composing=false;
const mods=new Set(),physical=new Set();
function translate(){document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';document.querySelectorAll('[data-i18n]').forEach(e=>{e.textContent=t(e.dataset.i18n);if(e.tagName==='H1')e.style.whiteSpace='pre-line';});document.querySelectorAll('[data-placeholder]').forEach(e=>e.placeholder=t(e.dataset.placeholder));$('status').textContent=t(authToken?'connected':'offline');hint();}
$('deviceName').value=storage.get('rt-name')||(/Android|iPhone|iPad/i.test(navigator.userAgent)?'My phone':'My computer');
$('useTrust').disabled=!storage.get(deviceStorageKey);$('useTrust').onchange=()=>{$('pairCode').required=!$('useTrust').checked;$('pairCode').disabled=$('useTrust').checked;};
$('forget').onclick=()=>{storage.remove(deviceStorageKey);$('useTrust').checked=false;$('useTrust').disabled=true;$('useTrust').onchange();};
async function api(route,options={}) {
  const tokenAtStart=authToken;let response;
  try{response=await fetch(apiBase+'/api'+route,{...options,headers:{...(company?{'X-RT-Host':hostId}:{}),...(tokenAtStart?{Authorization:'Bearer '+tokenAtStart}:{}),...options.headers},signal:options.signal||AbortSignal.timeout(route.startsWith('/files/')||route==='/pair'?34000:10000)});}catch(e){throw new Error(t('network'));}
  if(!response.ok){let error;try{error=(await response.json()).error;}catch{}if(response.status===401&&tokenAtStart===authToken)finish(t('ended'));const failure=new Error(error||'HTTP '+response.status);failure.status=response.status;throw failure;}
  return response;
}
const post=async(route,value={},options={})=>{const current=authToken;const r=await api(route,{method:'POST',body:JSON.stringify(value),headers:{'content-type':'application/json'},...options});const result=await r.json();if(current===authToken&&Number.isInteger(result.epoch))epoch=Math.max(epoch,result.epoch);return result;};
function note(message){$('sessionMessage').textContent=message;}
function populateMonitors(){const select=$('monitor');select.replaceChildren();for(const m of monitors){const o=document.createElement('option');o.value=m.id;o.textContent=`${m.id+1} · ${m.width} × ${m.height}${m.primary?' · Primary':''}`;select.append(o);}select.value=String(monitor);}
$('pairForm').onsubmit=async e=>{
  e.preventDefault();if(!configured)return;hostId=$('computerId').value.trim();deviceStorageKey='rt-device:'+apiBase+':'+hostId;$('pairButton').disabled=true;$('pairMessage').textContent=t('pending');
  try{
    const name=$('deviceName').value.trim();storage.set('rt-name',name);
    const result=await post('/pair',{name,code:$('pairCode').value,deviceToken:$('useTrust').checked?storage.get('rt-device'):null});
    authToken=result.token;epoch=result.epoch||0;if(result.deviceToken){storage.set(deviceStorageKey,result.deviceToken);$('useTrust').disabled=false;}
    monitors=result.monitors;monitor=monitors.find(m=>m.primary)?.id??0;populateMonitors();seq=0;queue=[];firstFrame=true;lastGood=Date.now();frameGeneration++;
    $('connect').hidden=true;$('session').hidden=false;document.body.classList.add('connected');$('screenLoading').hidden=false;$('pairMessage').textContent='';$('pairCode').value='';$('status').textContent=t('connected');setMode('direct');fit();stream(frameGeneration);$('viewport').focus();
  }catch(err){$('pairMessage').textContent=err.message;}finally{$('pairButton').disabled=false;}
};
function finish(message){authToken=null;frameGeneration++;queue=[];mods.clear();physical.clear();dragLock=false;$('drag').setAttribute('aria-pressed','false');document.querySelectorAll('[data-mod]').forEach(b=>b.setAttribute('aria-pressed','false'));pointers.clear();gesture=null;$('connect').hidden=false;$('session').hidden=true;document.body.classList.remove('connected');$('status').textContent=t('offline');$('pairMessage').textContent=message;transferGeneration++;transferAbort?.abort();if(frameURL){URL.revokeObjectURL(frameURL);frameURL=null;}$('screen').removeAttribute('src');}
$('disconnect').onclick=async()=>{try{await post('/disconnect');}catch{}finish(t('ended'));};
function enqueue(event){if(!authToken||mode==='viewMode'&&event.type!=='release')return;if(queue.length>=256){release();note('Input backlog cleared');return;}const last=queue.at(-1);if(event.type==='move'&&last?.type==='move')queue[queue.length-1]=event;else if(event.type==='relative'&&last?.type==='relative'){last.dx+=event.dx;last.dy+=event.dy;}else queue.push(event);flush();}
async function flush(){if(sending||releasing||!authToken||!queue.length)return;sending=true;const events=queue.splice(0,64);try{await post('/input',{seq:++seq,epoch,events});}catch(e){queue=[];note(e.message);if(authToken)release();}finally{sending=false;if(queue.length)flush();}}
function release(){queue=[];mods.clear();physical.clear();dragLock=false;document.querySelectorAll('[data-mod]').forEach(b=>b.setAttribute('aria-pressed','false'));$('drag').setAttribute('aria-pressed','false');if(authToken){releasing++;post('/release',{}, {keepalive:true}).catch(()=>{}).finally(()=>{releasing--;flush();});}}
function button(name,down){enqueue({type:'button',button:name,down});}
function click(name='left'){button(name,true);button(name,false);}
function setMode(value){release();mode=value;for(const id of ['direct','touchpad','viewMode'])$(id).classList.toggle('selected',id===mode);hint();}
function hint(){$('gestureHint').textContent=t(mode==='direct'?'directHint':mode==='touchpad'?'touchpadHint':'viewHint');}
for(const id of ['direct','touchpad','viewMode'])$(id).onclick=()=>setMode(id);
$('left').onclick=()=>click();$('right').onclick=()=>click('right');$('drag').onclick=()=>{if(mode==='viewMode')return;dragLock=!dragLock;$('drag').setAttribute('aria-pressed',String(dragLock));button('left',dragLock);};
$('scrollUp').onclick=()=>enqueue({type:'wheel',x:0,y:-120});$('scrollDown').onclick=()=>enqueue({type:'wheel',x:0,y:120});
function transform(){$('canvasWrap').style.transform=`translate(${offsetX}px,${offsetY}px) scale(${scale})`;}
function fit(){const m=monitors.find(m=>m.id===monitor);if(m){sourceWidth=m.width;sourceHeight=m.height;}$('screen').style.width=sourceWidth+'px';$('screen').style.height=sourceHeight+'px';const r=$('viewport').getBoundingClientRect();scale=Math.min(r.width/sourceWidth,r.height/sourceHeight);offsetX=(r.width-sourceWidth*scale)/2;offsetY=(r.height-sourceHeight*scale)/2;fitMode=true;transform();}
function zoom(newScale,x=$('viewport').clientWidth/2,y=$('viewport').clientHeight/2){fitMode=false;newScale=Math.max(.05,Math.min(6,newScale));offsetX=zoomAt(scale,newScale,offsetX,x);offsetY=zoomAt(scale,newScale,offsetY,y);scale=newScale;transform();}
$('fit').onclick=fit;$('actual').onclick=()=>zoom(1);$('zoomIn').onclick=()=>zoom(scale*1.25);$('zoomOut').onclick=()=>zoom(scale/1.25);
new ResizeObserver(()=>{if(fitMode)fit();}).observe($('viewport'));
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if($('session').requestFullscreen)await $('session').requestFullscreen();else note(t('fullUnsupported'));}catch{note(t('fullUnsupported'));}};
$('collapse').onclick=()=>{$('toolbar').hidden=!$('toolbar').hidden;$('collapse').setAttribute('aria-expanded',String(!$('toolbar').hidden));};
$('keyboardButton').onclick=()=>{$('keyboardPanel').hidden=!$('keyboardPanel').hidden;if(!$('keyboardPanel').hidden){$('typing').focus();$('typing').scrollIntoView({block:'nearest'});}};
$('settingsButton').onclick=()=>{$('settingsPanel').hidden=!$('settingsPanel').hidden;};
const modifierNames={ControlLeft:'Ctrl',AltLeft:'Alt',ShiftLeft:'Shift',MetaLeft:'Win'};
const special={Escape:'Esc',Tab:'Tab',Backspace:'⌫',Delete:'Del',Enter:'Enter',ArrowLeft:'←',ArrowUp:'↑',ArrowDown:'↓',ArrowRight:'→',Home:'Home',End:'End',PageUp:'PgUp',PageDown:'PgDn',...Object.fromEntries(Array.from({length:12},(_,i)=>['F'+(i+1),'F'+(i+1)]))};
for(const [code,label] of Object.entries({...modifierNames,...special})) {const b=document.createElement('button');b.textContent=label;b.type='button';if(modifierNames[code]){b.dataset.mod=code;b.setAttribute('aria-pressed','false');}b.onclick=()=>{if(mode==='viewMode')return;if(modifierNames[code]){const down=!mods.has(code);if(down)mods.add(code);else mods.delete(code);b.setAttribute('aria-pressed',String(down));enqueue({type:'key',code,down});}else{enqueue({type:'key',code,down:true});enqueue({type:'key',code,down:false});}};$('keybar').append(b);}
for(const [label,codes] of Object.entries({'Ctrl+A':['ControlLeft','KeyA'],'Ctrl+C':['ControlLeft','KeyC'],'Ctrl+V':['ControlLeft','KeyV'],'Ctrl+S':['ControlLeft','KeyS'],'Ctrl+Z':['ControlLeft','KeyZ'],'Alt+Tab':['AltLeft','Tab'],'Ctrl+Shift+Esc':['ControlLeft','ShiftLeft','Escape']})){const b=document.createElement('button');b.textContent=label;b.onclick=()=>{release();for(const code of codes)enqueue({type:'key',code,down:true});for(const code of [...codes].reverse())enqueue({type:'key',code,down:false});};$('keybar').append(b);}
$('typing').addEventListener('compositionstart',()=>composing=true);$('typing').addEventListener('compositionend',()=>composing=false);
$('sendText').onclick=()=>{if(composing||!$('typing').value||!authToken||mode==='viewMode')return;const text=$('typing').value;release();enqueue({type:'text',text});$('typing').value='';note(t('typingSent'));$('typing').focus();};
const editable=e=>e.target.closest('input,textarea,select,button');
function normalizedCode(code){return {ControlRight:'ControlLeft',ShiftRight:'ShiftLeft',AltRight:'AltLeft',MetaRight:'MetaLeft'}[code]||code;}
document.addEventListener('keydown',e=>{if(!authToken||mode==='viewMode'||editable(e)||e.isComposing)return;const code=normalizedCode(e.code);if(modifierNames[code]||special[code]||((e.ctrlKey||e.altKey||e.metaKey||mods.size)&&/^(Key[A-Z]|Digit\d)$/.test(code))){e.preventDefault();if(!physical.has(code)){physical.add(code);enqueue({type:'key',code,down:true});}}else if(e.key.length===1&&!e.ctrlKey&&!e.altKey&&!e.metaKey){e.preventDefault();enqueue({type:'text',text:e.key});}});
document.addEventListener('keyup',e=>{const code=normalizedCode(e.code);if(physical.has(code)){e.preventDefault();physical.delete(code);enqueue({type:'key',code,down:false});}});
window.addEventListener('blur',()=>{release();pointers.clear();gesture=null;});
document.addEventListener('visibilitychange',()=>{if(document.hidden){release();pointers.clear();gesture=null;}});
window.addEventListener('pagehide',()=>{release();if(authToken)post('/disconnect',{}, {keepalive:true}).catch(()=>{});});
const surface=$('viewport'),pointers=new Map();let gesture=null,lastTap=0;
function point(e){return remotePoint(e.clientX,e.clientY,$('screen').getBoundingClientRect());}
function moveTo(e){const p=point(e);if(p)enqueue({type:'move',monitor,...p});return p;}
function centroid(){const a=[...pointers.values()];return{x:a.reduce((s,p)=>s+p.x,0)/a.length,y:a.reduce((s,p)=>s+p.y,0)/a.length};}
function distance(){const a=[...pointers.values()];return a.length<2?0:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);}
surface.addEventListener('contextmenu',e=>e.preventDefault());
surface.addEventListener('pointerdown',e=>{
  if(!authToken||firstFrame)return;e.preventDefault();surface.focus({preventScroll:true});surface.setPointerCapture(e.pointerId);
  if(e.pointerType==='mouse'&&mode!=='viewMode'){if(moveTo(e))button(['left','middle','right'][e.button]||'left',true);return;}
  pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pointers.size===1){gesture={start:performance.now(),x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,moved:0,two:false,drag:false};if(mode==='touchpad'&&performance.now()-lastTap<300&&!dragLock){gesture.drag=true;button('left',true);}}
  else if(pointers.size===2&&gesture){if(gesture.drag){button('left',false);gesture.drag=false;}gesture.two=true;gesture.center=centroid();gesture.distance=distance();}
});
surface.addEventListener('pointermove',e=>{
  if(!authToken||firstFrame)return;
  if(e.pointerType==='mouse'&&mode!=='viewMode'){moveTo(e);return;}
  if(!pointers.has(e.pointerId)||!gesture)return;e.preventDefault();pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  const g=gesture;
  if(pointers.size>=2){const c=centroid(),dx=c.x-g.center.x,dy=c.y-g.center.y;g.moved+=Math.abs(dx)+Math.abs(dy);if(mode==='viewMode'){const d=distance(),r=surface.getBoundingClientRect();if(g.distance>0)zoom(scale*d/g.distance,c.x-r.left,c.y-r.top);offsetX+=dx;offsetY+=dy;transform();g.distance=d;}else if(g.moved>=12)enqueue({type:'wheel',x:Math.round(-dx*3),y:Math.round(-dy*3)});g.center=c;return;}
  if(g.two)return;const dx=e.clientX-g.lastX,dy=e.clientY-g.lastY;g.moved+=Math.abs(dx)+Math.abs(dy);
  if(mode==='viewMode'){fitMode=false;offsetX+=dx;offsetY+=dy;transform();}
  else if(mode==='touchpad'){const sensitivity=Number($('sensitivity').value);enqueue({type:'relative',dx:dx*sensitivity,dy:dy*sensitivity});}
  else if(g.moved>7){if(!g.drag&&!dragLock){const p=remotePoint(g.x,g.y,$('screen').getBoundingClientRect());if(p){enqueue({type:'move',monitor,...p});button('left',true);g.drag=true;}}moveTo(e);}
  g.lastX=e.clientX;g.lastY=e.clientY;
});
function pointerEnd(e,cancelled=false){
  if(e.pointerType==='mouse'&&mode!=='viewMode'){button(['left','middle','right'][e.button]||'left',false);return;}
  if(!pointers.has(e.pointerId)||!gesture)return;pointers.delete(e.pointerId);if(pointers.size)return;
  const g=gesture;gesture=null;if(g.drag)button('left',false);
  if(cancelled){release();return;}if(mode==='viewMode')return;
  if(g.moved<12&&performance.now()-g.start<500&&!g.drag&&!dragLock){if(mode==='direct')moveTo(e);click(g.two?'right':'left');lastTap=performance.now();}
}
surface.addEventListener('pointerup',e=>pointerEnd(e));surface.addEventListener('pointercancel',e=>pointerEnd(e,true));
surface.addEventListener('wheel',e=>{if(!authToken)return;e.preventDefault();if(mode==='viewMode'||e.ctrlKey){const r=surface.getBoundingClientRect();zoom(scale*Math.exp(-e.deltaY*.002),e.clientX-r.left,e.clientY-r.top);}else{moveTo(e);const factor=e.deltaMode===1?16:e.deltaMode===2?500:1;enqueue({type:'wheel',x:e.deltaX*factor,y:e.deltaY*factor});}},{passive:false});
$('quality').oninput=()=>{$('qualityValue').value=$('quality').value;quality=Number($('quality').value);};$('resolution').onchange=()=>width=Number($('resolution').value);
$('monitor').onchange=()=>{release();monitor=Number($('monitor').value);firstFrame=true;$('screenLoading').hidden=false;fit();};
$('refreshMonitors').onclick=async()=>{try{monitors=(await(await api('/monitors')).json()).monitors;if(!monitors.some(m=>m.id===monitor))monitor=monitors[0].id;populateMonitors();fit();}catch(e){note(e.message);}};
let frameURL=null;
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function stream(generation){
  let goodFrames=0;
  while(authToken&&generation===frameGeneration){
    if(document.hidden){await delay(400);continue;}
    const start=performance.now(),selectedMonitor=monitor;
    try{
      const response=await api(`/frame?monitor=${selectedMonitor}&width=${width}&quality=${quality}`),blob=await response.blob();
      if(!authToken||generation!==frameGeneration)break;if(monitor!==selectedMonitor)continue;
      const url=URL.createObjectURL(blob),img=new Image();img.src=url;try{await img.decode();}catch{URL.revokeObjectURL(url);throw new Error(t('decode'));}
      const previous=frameURL;frameURL=url;$('screen').src=url;if(previous)URL.revokeObjectURL(previous);firstFrame=false;$('screenLoading').hidden=true;lastGood=Date.now();frames++;
      const elapsed=performance.now()-start,target=1000/Number($('fps').value);
      if($('adaptive').checked){if(elapsed>Math.max(140,target*2)){quality=Math.max(30,quality-5);if(quality<=40)width=Math.max(640,Math.round(width*.9));goodFrames=0;}else if(++goodFrames>40){quality=Math.min(Number($('quality').value),quality+2);width=Math.min(Number($('resolution').value),Math.round(width*1.05));goodFrames=0;}}
      else{quality=Number($('quality').value);width=Number($('resolution').value);}
      if(performance.now()-lastMetrics>1000){renderFps=frames*1000/(performance.now()-lastMetrics);frames=0;lastMetrics=performance.now();$('metrics').textContent=`${renderFps.toFixed(1)} fps · ${Math.round(rtt)} ms RTT · ${img.naturalWidth} × ${img.naturalHeight} · Q${quality}`;$('monitorTitle').textContent=`${t('monitor')} ${monitor+1}`;}
      await delay(Math.max(0,target-(performance.now()-start)));
    }catch(e){if(!authToken)break;if(e.status===409&&e.message.includes('host file approval')){lastGood=Date.now();note(t('waitingFile'));await delay(400);continue;}release();note(e.message+' · '+t('reconnecting'));if(Date.now()-lastGood>15000){try{await post('/disconnect');}catch{}finish(t('ended'));break;}await delay(800);}
  }
}
let heartbeatBusy=false;
setInterval(async()=>{if(!authToken||heartbeatBusy)return;heartbeatBusy=true;const start=performance.now();try{await post('/heartbeat');rtt=performance.now()-start;$('status').textContent=t('connected');}catch{if(authToken){release();$('status').textContent=t('reconnecting');}}finally{heartbeatBusy=false;}},1000);
$('clipboardGet').onclick=async()=>{try{$('clipboardText').value=(await(await api('/clipboard')).json()).text;note(t('clipboardReady'));}catch(e){note(e.message);}};
$('clipboardSet').onclick=async()=>{try{await post('/clipboard',{text:$('clipboardText').value});note(t('clipboardReady'));}catch(e){note(e.message);}};
let transferGeneration=0,transferAbort=null,transferBusy=false;
function fileStatus(s){$('fileStatus').textContent=s;}
function setTransferBusy(b){transferBusy=b;$('upload').disabled=b;$('download').disabled=b;}
async function cancelFile(){transferGeneration++;transferAbort?.abort();try{if(authToken)await post('/files/cancel');}catch{}setTransferBusy(false);fileStatus(t('cancelled'));}
$('cancelTransfer').onclick=cancelFile;
$('upload').onchange=async()=>{
  const file=$('upload').files[0];if(!file||transferBusy)return;const generation=++transferGeneration;setTransferBusy(true);transferAbort=new AbortController();$('progress').value=0;fileStatus(t('waitingFile'));
  try{
    const {id}=await post('/files/upload',{name:file.name,size:file.size});if(generation!==transferGeneration)return;
    let offset=0;do{if(generation!==transferGeneration)return;const chunk=file.slice(offset,offset+256*1024);const r=await api(`/files/chunk?id=${encodeURIComponent(id)}&offset=${offset}`,{method:'PUT',body:chunk,signal:transferAbort.signal});const result=await r.json();offset=result.offset;$('progress').value=file.size?offset/file.size*100:100;fileStatus(`${t('transferring')} ${Math.round($('progress').value)}%`);}while(offset<file.size);fileStatus(t('complete')+' · '+t('saved'));
  }catch(e){if(generation===transferGeneration){fileStatus(e.message);try{await post('/files/cancel');}catch{}}}finally{if(generation===transferGeneration)setTransferBusy(false);$('upload').value='';}
};
$('download').onclick=async()=>{
  if(transferBusy)return;const generation=++transferGeneration;setTransferBusy(true);transferAbort=new AbortController();$('progress').value=0;fileStatus(t('waitingFile'));
  try{const info=await post('/files/download');if(generation!==transferGeneration)return;const chunks=[];let offset=0;while(offset<info.size){if(generation!==transferGeneration)return;const response=await api(`/files/chunk?id=${encodeURIComponent(info.id)}&offset=${offset}`,{signal:transferAbort.signal});const chunk=await response.arrayBuffer();if(!chunk.byteLength)throw new Error('File changed while downloading');chunks.push(chunk);offset+=chunk.byteLength;$('progress').value=offset/info.size*100;fileStatus(`${t('transferring')} ${Math.round($('progress').value)}%`);}const url=URL.createObjectURL(new Blob(chunks));const a=document.createElement('a');a.href=url;a.download=info.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);await post('/files/cancel');$('progress').value=100;fileStatus(t('complete'));}catch(e){if(generation===transferGeneration){fileStatus(e.message);try{await post('/files/cancel');}catch{}}}finally{if(generation===transferGeneration)setTransferBusy(false);}
};
translate();
