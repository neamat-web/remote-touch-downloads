import https from 'node:https';
import {startBridge} from './relay-client.mjs';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import readline from 'node:readline';
import { X509Certificate, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { PairCode, Limiter, token, digest, equal, clamp, safeName, allowedAddress, validateInput } from './security.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'), data=path.join(root,'.data');
// The private key is DPAPI-protected on disk. Only the owning host process can
// decrypt it; bootstrap transfers it over inherited anonymous pipes, never TCP.
const input=readline.createInterface({input:process.stdin});
const boot=await new Promise((resolve,reject)=>{input.once('line',line=>{try{const b=JSON.parse(line);if(b.type!=='bootstrap'||typeof b.pfx!=='string')throw new Error('Launch through RemoteTouch.exe');resolve(b);}catch(e){reject(e);}});input.once('close',()=>reject(new Error('Host disconnected before bootstrap')));});
const bind=boot.bind==='0.0.0.0'?'0.0.0.0':'127.0.0.1';
const port=Number(boot.port||8443);
if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('RT_PORT must be 1024–65535');
const pending=new Map(), emit=v=>process.stdout.write(JSON.stringify(v)+'\n');
function native(type,payload={},timeout=5000) {
  return new Promise((resolve,reject)=>{const id=randomUUID();const timer=setTimeout(()=>{pending.delete(id);reject(new Error('Host timed out'));},timeout);pending.set(id,{resolve,reject,timer});emit({type,id,...payload});});
}
let session=null, approving=false, trusts=[], stopBridge=null, sessionGeneration=0;
const pair=new PairCode(), pairIP=new Limiter(5,60000), pairGlobal=new Limiter(20,60000), requests=new Limiter(500,1000);
const trustPath=path.join(data,'trusted-devices.json');
try{trusts=JSON.parse(fs.readFileSync(trustPath,'utf8')).filter(t=>t.expires>Date.now()).slice(0,50);}catch{}
function listTrusts(){emit({type:'trusts',items:trusts.map(({id,name})=>({id,name}))});}
function saveTrusts(){fs.writeFileSync(trustPath+'.tmp',JSON.stringify(trusts));fs.renameSync(trustPath+'.tmp',trustPath);listTrusts();}
function showCode(){emit({type:'code',code:pair.code,expires:pair.expires});}
async function cancelTransfer(s) {
  const t=s?.transfer;if(!t)return;s.transfer=null;t.cancelled=true;
  if(!t.busy)await cleanTransfer(t);
}
async function cleanTransfer(t){try{await t.handle?.close();}catch{}if(t.kind==='upload'&&!t.complete)await fsp.unlink(t.path).catch(()=>{});}
function releaseInput(s){if(s)s.epoch++;emit({type:'release'});}
function endSession(reason='Ended by host') {
  sessionGeneration++;
  if(session){const old=session;session=null;old.ended=true;cancelTransfer(old);}
  emit({type:'release'});emit({type:'active',active:false});
}
input.on('line',line=>{
  try {
    const m=JSON.parse(line);
    if(m.type==='reply'){const p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(new Error(m.error)):p.resolve(m.result);}}
    else if(m.type==='newCode'){pair.rotate();showCode();}
    else if(m.type==='clipboardPolicy'){if(session)session.clipboard=m.enabled===true;}
    else if(m.type==='revoke'){trusts=trusts.filter(t=>t.id!==m.id);saveTrusts();if(session?.trustId===m.id)endSession();}
  }catch{console.error('Malformed local IPC message');}
});
input.on('close',()=>{stopBridge?.();endSession();server.close();setTimeout(()=>process.exit(0),100).unref();});
function json(res,status,obj){if(res.destroyed)return;res.writeHead(status,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(obj));}
function fail(status,message){const e=new Error(message);e.status=status;throw e;}
async function readBody(req,max=65536) {
  const chunks=[];let size=0;
  for await(const c of req){size+=c.length;if(size>max)fail(413,'Request too large');chunks.push(c);}return Buffer.concat(chunks);
}
async function body(req,max=65536) {try{return JSON.parse((await readBody(req,max)).toString('utf8'));}catch(e){if(e.status)throw e;fail(400,'Invalid JSON');}}
function auth(req){
  if(!session||session.ended||!equal(req.headers.authorization,'Bearer '+session.token))fail(401,'Session ended. Pair again.');
  if(Date.now()-session.lastSeen>15000){endSession();fail(401,'Session expired. Pair again.');}
  session.lastSeen=Date.now();return session;
}
function same(s){if(session!==s||s.ended)fail(401,'Session ended');}
function sendBinary(res,buffer,headers={}){res.writeHead(200,{'content-type':'application/octet-stream','content-length':buffer.length,...headers});res.end(buffer);}
function credentials(req){return typeof req.headers.host==='string'&&hostNames.has(req.headers.host.toLowerCase())&&(!req.headers.origin||req.headers.origin==='https://'+req.headers.host);}
const ips=Object.values(os.networkInterfaces()).flat().filter(x=>x&&x.family==='IPv4').map(x=>x.address);
const names=['localhost',os.hostname(),...ips,...String(boot.names||'').split(',').map(x=>x.trim()).filter(Boolean)];
const hostNames=new Set(names.map(x=>(x+':'+port).toLowerCase()));
const publicFiles=new Map([['/config.json','config.json'],['/','index.html'],['/app.mjs','app.mjs'],['/geometry.mjs','geometry.mjs'],['/style.css','style.css']]);
const tls={pfx:Buffer.from(boot.pfx,'base64'),passphrase:'',minVersion:'TLSv1.2'};delete boot.pfx;
const server=https.createServer(tls,async(req,res)=>{
  res.setHeader('cache-control','no-store');res.setHeader('x-content-type-options','nosniff');res.setHeader('referrer-policy','no-referrer');
  res.setHeader('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  res.setHeader('permissions-policy','camera=(), microphone=(), geolocation=()');
  let s;
  try {
    const ip=req.socket.remoteAddress;
    if(!allowedAddress(ip))fail(403,'Only private LAN/VPN addresses are permitted');
    if(!credentials(req))fail(403,'Unrecognized host or cross-origin request');
    if(!requests.allow(ip))fail(429,'Too many requests');
    const url=new URL(req.url,'https://'+req.headers.host),route=url.pathname;
    if(publicFiles.has(route)&&req.method==='GET'){
      const name=publicFiles.get(route);res.setHeader('content-type',name.endsWith('.css')?'text/css; charset=utf-8':name.endsWith('.mjs')?'text/javascript; charset=utf-8':'text/html; charset=utf-8');res.end(await fsp.readFile(path.join(root,'web',name)));return;
    }
    if(route==='/api/pair'&&req.method==='POST') {
      if(!pairIP.allow(ip)||!pairGlobal.allow('all'))fail(429,'Too many pairing attempts. Wait one minute.');
      const m=await body(req,2048);
      if(session||approving)fail(409,'Host is busy. Only one controller is allowed.');
      const trusted=typeof m.deviceToken==='string'?trusts.find(t=>t.expires>Date.now()&&equal(t.hash,digest(m.deviceToken))):null;
      if(!trusted&&!pair.use(m.code))fail(403,'Incorrect or expired pairing code');
      if(!trusted)showCode();
      const name=String(m.name||'Browser').replace(/[\x00-\x1f\u202a-\u202e\u2066-\u2069]/g,'').slice(0,60);
      approving=true;const approvalGeneration=sessionGeneration;
      try {
        const approval=await native('approval',{name,address:ip,trusted:!!trusted},31000);
        if(approvalGeneration!==sessionGeneration)fail(409,'Connection interrupted. Request approval again.');
        if(!approval.approved)fail(403,'Connection declined or approval timed out');
        if(res.destroyed) return;
        const monitors=await native('monitors');
        if(approvalGeneration!==sessionGeneration)fail(409,'Connection interrupted. Request approval again.');
        let deviceToken=null,trustId=trusted?.id;
        if(approval.remember&&!trusted) {
          if(trusts.length>=50)fail(409,'Revoke an old trusted device first');
          deviceToken=token();trustId=randomUUID();trusts.push({id:trustId,name,hash:digest(deviceToken),expires:Date.now()+30*86400000});saveTrusts();
        }
        session={token:token(),name,trustId,lastSeen:Date.now(),clipboard:false,monitor:monitors.find(m=>m.primary)?.id??0,monitors,frameBusy:false,inputBusy:false,seq:0,epoch:0,transfer:null};
        emit({type:'active',active:true,name});
        json(res,200,{token:session.token,deviceToken,monitors,epoch:0,capabilities:{audio:false,clipboard:true,files:true,unattended:false},transport:'HTTPS JPEG'});
      }finally{approving=false;}
      return;
    }
    s=auth(req);
    if(route==='/api/heartbeat'&&req.method==='POST'){emit({type:'heartbeat'});json(res,200,{now:Date.now(),clipboard:s.clipboard,epoch:s.epoch,consent:!!s.consent});return;}
    if(route==='/api/disconnect'&&req.method==='POST'){endSession('Client disconnected');json(res,200,{ok:true});return;}
    if(route==='/api/release'&&req.method==='POST'){releaseInput(s);json(res,200,{ok:true,epoch:s.epoch});return;}
    if(route==='/api/monitors'&&req.method==='GET'){const monitors=await native('monitors');same(s);s.monitors=monitors;json(res,200,{monitors});return;}
    if(route==='/api/frame'&&req.method==='GET') {
      if(s.consent)fail(409,'Paused for host file approval');if(s.frameBusy)fail(409,'One frame at a time');s.frameBusy=true;
      try {
        const monitor=Number(url.searchParams.get('monitor')||0);if(!Number.isInteger(monitor)||!s.monitors.some(x=>x.id===monitor))fail(400,'Invalid monitor');
        if(s.monitor!==monitor){emit({type:'release'});s.monitor=monitor;}
        const result=await native('capture',{monitor,width:Math.round(clamp(Number(url.searchParams.get('width')),320,3840,1600)),quality:Math.round(clamp(Number(url.searchParams.get('quality')),25,95,65))},8000);same(s);
        if(s.consent)fail(409,'Paused for host file approval');sendBinary(res,Buffer.from(result.jpeg,'base64'),{'content-type':'image/jpeg'});
      }finally{s.frameBusy=false;}return;
    }
    if(route==='/api/input'&&req.method==='POST') {
      const m=await body(req);
      if(!Number.isSafeInteger(m.seq)||m.seq<=s.seq||m.epoch!==s.epoch)fail(409,'Stale input rejected; release controls and retry');
      if(s.inputBusy)fail(409,'Input requests must be serialized');
      if(!Array.isArray(m.events)||m.events.length>64)fail(400,'Input batch limit exceeded');
      const events=m.events.map(validateInput);
      if(events.some(e=>e.type==='move'&&e.monitor!==s.monitor))fail(409,'Wait for the selected monitor frame');
      if(s.consent)fail(409,'Input paused while the host reviews file sharing');
      s.seq=m.seq;s.inputBusy=true;
      try{const result=await native('input',{events});same(s);json(res,200,result);}finally{s.inputBusy=false;}return;
    }
    if(route==='/api/clipboard'&&(req.method==='GET'||req.method==='POST')) {
      if(!s.clipboard)fail(403,'Enable clipboard in the Windows host window first');
      let result;if(req.method==='GET')result=await native('clipboardGet');else{const m=await body(req,300000);if(typeof m.text!=='string'||m.text.length>65536)fail(400,'Clipboard limit: 65536 characters');result=await native('clipboardSet',{text:m.text});}same(s);json(res,200,result);return;
    }
    if(route==='/api/files/upload'&&req.method==='POST') {
      if(s.transfer)fail(409,'Finish or cancel the current transfer');
      const m=await body(req,2048),name=safeName(m.name),size=m.size;
      if(!Number.isSafeInteger(size)||size<0||size>100*1024*1024)fail(400,'File limit: 100 MiB');
      const t={id:token(),kind:'pending',last:Date.now()};s.transfer=t;
      try {
        s.consent=true;releaseInput(s);
        let r;try{r=await native('uploadApproval',{name,size},31000);}finally{s.consent=false;}
        same(s);if(s.transfer!==t)fail(409,'Transfer cancelled');if(!r.approved)fail(403,'Host declined file');
        const folder=path.join(data,'Received');await fsp.mkdir(folder,{recursive:true});
        Object.assign(t,{kind:'upload',name,size,offset:0,path:path.join(folder,randomUUID()+'.part'),busy:false});t.handle=await fsp.open(t.path,'wx');
        json(res,200,{id:t.id,epoch:s.epoch});
      }catch(e){await cancelTransfer(s);throw e;}return;
    }
    if(route==='/api/files/download'&&req.method==='POST') {
      if(s.transfer)fail(409,'Finish or cancel the current transfer');const t={id:token(),kind:'pending',last:Date.now()};s.transfer=t;
      try {
        s.consent=true;releaseInput(s);
        let r;try{r=await native('downloadSelect',{},31000);}finally{s.consent=false;}
        same(s);if(s.transfer!==t)fail(409,'Transfer cancelled');if(!r.path)fail(403,'No file selected by host');
        const stat=await fsp.stat(r.path);if(!stat.isFile()||stat.size>100*1024*1024)fail(400,'Select a file up to 100 MiB');
        Object.assign(t,{kind:'download',name:path.basename(r.path),size:stat.size,handle:await fsp.open(r.path,'r'),busy:false});json(res,200,{id:t.id,name:t.name,size:t.size,epoch:s.epoch});
      }catch(e){await cancelTransfer(s);throw e;}return;
    }
    if(route==='/api/files/cancel'&&req.method==='POST'){await cancelTransfer(s);json(res,200,{ok:true});return;}
    if(route==='/api/files/chunk') {
      const t=s.transfer;if(!t||!equal(url.searchParams.get('id'),t.id))fail(404,'Transfer not found');
      if(t.busy)fail(409,'Transfer busy');t.busy=true;t.last=Date.now();
      try {
        const offset=Number(url.searchParams.get('offset'));if(!Number.isSafeInteger(offset)||offset<0||offset>t.size)fail(400,'Invalid offset');
        if(t.kind==='upload'&&req.method==='PUT') {
          if(offset!==t.offset)fail(409,'Unexpected offset');const b=await readBody(req,256*1024);same(s);if(t.cancelled)fail(409,'Transfer cancelled');
          if(t.offset+b.length>t.size)fail(400,'File exceeds declared size');
          let written=0;while(written<b.length){const r=await t.handle.write(b,written,b.length-written,t.offset+written);if(!r.bytesWritten)throw new Error('Disk write failed');written+=r.bytesWritten;}t.offset+=written;
          if(t.cancelled)fail(409,'Transfer cancelled');
          if(t.offset===t.size){await t.handle.close();t.handle=null;const saved=randomUUID()+'-'+t.name;await fsp.rename(t.path,path.join(data,'Received',saved));t.complete=true;s.transfer=null;json(res,200,{offset:t.offset,complete:true,saved});}
          else json(res,200,{offset:t.offset,complete:false});
        } else if(t.kind==='download'&&req.method==='GET') {
          const b=Buffer.alloc(Math.min(256*1024,t.size-offset)),r=await t.handle.read(b,0,b.length,offset);same(s);if(t.cancelled)fail(409,'Transfer cancelled');sendBinary(res,b.subarray(0,r.bytesRead));
        }else fail(405,'Wrong transfer method');
      }finally{t.busy=false;if(t.cancelled)await cleanTransfer(t);}return;
    }
    fail(404,'Route not found');
  }catch(e){if(!res.headersSent)json(res,e.status||400,{error:e.message||'Request failed'});else res.destroy();}
});
server.maxConnections=50;server.requestTimeout=35000;server.headersTimeout=10000;server.keepAliveTimeout=5000;
server.on('clientError',(_,socket)=>socket.destroy());
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Port already in use. Change RT_PORT in .env.':e.message);process.exit(1);});
server.listen(port,bind,()=>{
  const cert=new X509Certificate(fs.readFileSync(path.join(data,'RemoteTouch-CA.cer')));
  const addresses=(bind==='127.0.0.1'?['127.0.0.1']:ips.filter(allowedAddress)).map(ip=>'https://'+ip+':'+port).join('\r\n');
  emit({type:'ready',addresses,fingerprint:cert.fingerprint256});showCode();listTrusts();
  if(boot.relayUrl){stopBridge=startBridge({url:boot.relayUrl,id:boot.relayId,key:boot.relayKey,port,ca:cert.toString(),onLost:()=>endSession('Company connection lost'),onStatus:(url,hostId)=>emit({type:'companyStatus',online:!!url,url,hostId})});delete boot.relayKey;}
});
setInterval(()=>{
  if(Date.now()>pair.expires){pair.rotate();showCode();}
  if(session&&Date.now()-session.lastSeen>15000)endSession('Network timed out');
  else if(session&&Date.now()-session.lastSeen>3000)emit({type:'release'});
  if(session?.transfer&&Date.now()-session.transfer.last>60000)cancelTransfer(session);
},500).unref();
process.on('uncaughtException',e=>{emit({type:'release'});console.error(e.message);process.exit(1);});
