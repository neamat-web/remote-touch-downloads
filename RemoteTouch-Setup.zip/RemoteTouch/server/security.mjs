import { randomBytes, randomInt, createHash, timingSafeEqual } from 'node:crypto';
export const token = () => randomBytes(32).toString('base64url');
export const digest = s => createHash('sha256').update(s).digest('hex');
export function equal(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}
export class PairCode {
  constructor(now = Date.now) { this.now = now; this.rotate(); }
  rotate() { this.code = String(randomInt(0, 100000000)).padStart(8, '0'); this.expires = this.now() + 120000; }
  use(code) {
    if (this.now() >= this.expires || !equal(code, this.code)) return false;
    this.rotate(); return true;
  }
}
export class Limiter {
  constructor(limit, windowMs, now = Date.now) { Object.assign(this, {limit, windowMs, now}); this.entries = new Map(); }
  allow(key) {
    const now = this.now();
    for (const [k,v] of this.entries) if (v.end <= now) this.entries.delete(k);
    let v = this.entries.get(key);
    if (!v) { if (this.entries.size >= 2048) return false; this.entries.set(key, v = { n: 0, end: now + this.windowMs }); }
    return ++v.n <= this.limit;
  }
}
export function clamp(n, min, max, fallback) { return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback; }
export function safeName(s) {
  if (typeof s !== 'string' || !s.length || s.length > 120 || /[<>:"/\\|?*\x00-\x1f]/.test(s) || /[. ]$/.test(s) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)/i.test(s) || s === '.' || s === '..') throw new Error('Invalid file name');
  return s;
}
export function allowedAddress(ip) {
  ip = ip?.replace(/^::ffff:/, '');
  return ip === '::1' || /^(127\.|10\.|192\.168\.|169\.254\.)/.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip) || /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(ip) || /^f[cd][0-9a-f]{2}:/i.test(ip);
}
export const keyCodes = new Set(['Backspace','Tab','Enter','Escape','Space','PageUp','PageDown','End','Home','ArrowLeft','ArrowUp','ArrowRight','ArrowDown','Insert','Delete','ControlLeft','AltLeft','ShiftLeft','MetaLeft', ...Array.from({length:12},(_,i)=>'F'+(i+1)), ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(c=>'Key'+c), ...'0123456789'.split('').map(c=>'Digit'+c)]);
export function validateInput(m) {
  if (!m || typeof m !== 'object') throw new Error('Invalid input');
  switch(m.type) {
    case 'move':
      if (![m.x,m.y].every(Number.isFinite) || m.x<0 || m.x>1 || m.y<0 || m.y>1 || !Number.isInteger(m.monitor)) throw new Error('Invalid coordinate');
      return {type:m.type,x:m.x,y:m.y,monitor:m.monitor};
    case 'relative':
      if (![m.dx,m.dy].every(Number.isFinite)) throw new Error('Invalid delta');
      return {type:m.type,dx:clamp(m.dx,-500,500,0),dy:clamp(m.dy,-500,500,0)};
    case 'button':
      if (!['left','right','middle'].includes(m.button) || typeof m.down !== 'boolean') throw new Error('Invalid button');
      return {type:m.type,button:m.button,down:m.down};
    case 'key':
      if (!keyCodes.has(m.code) || typeof m.down !== 'boolean') throw new Error('Invalid key');
      return {type:m.type,code:m.code,down:m.down};
    case 'wheel':
      if (![m.x,m.y].every(Number.isFinite)) throw new Error('Invalid wheel');
      return {type:m.type,x:clamp(m.x,-1200,1200,0),y:clamp(m.y,-1200,1200,0)};
    case 'text':
      if (typeof m.text !== 'string' || m.text.length>4096) throw new Error('Text limit: 4096 characters');
      return {type:m.type,text:m.text};
    case 'release': return {type:'release'};
    default: throw new Error('Unknown input');
  }
}
