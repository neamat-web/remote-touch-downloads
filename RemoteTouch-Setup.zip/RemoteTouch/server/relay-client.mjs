import https from 'node:https';
import {validRequest,readLimited} from '../relay/protocol.mjs';

// Only an outbound, administrator-configured HTTPS connection. No incoming WAN port.
export function startBridge({url,id,key,port,ca,onLost,onStatus}){
  const remote=new URL(url);
  if(remote.protocol!=='https:'||remote.username||remote.password||remote.pathname!=='/'||remote.search||remote.hash)throw Error('Service address must be an HTTPS origin');
  if((id&&!/^[a-z0-9-]{6,64}$/.test(id))||! /^[A-Za-z0-9_-]{43}$/.test(key))throw Error('Invalid device configuration');
  const automaticRegistration=!id;
  let stopped=false,online=false;const inflight=new Set();const stopSignal=new AbortController();
  const agent=new https.Agent({ca,keepAlive:true,maxSockets:8});
  async function call(route,value,timeout=26000){
    const response=await fetch(remote.origin+route,{method:'POST',headers:{authorization:'Bearer '+key,'x-rt-host':id,'content-type':'application/json'},body:JSON.stringify(value),signal:AbortSignal.any([stopSignal.signal,AbortSignal.timeout(timeout)]),redirect:'error'});
    if(!response.ok)throw Object.assign(Error('Service HTTP '+response.status),{status:response.status});
    const b=await readLimited(response.body,600000);return b.length?JSON.parse(b.toString()):{};
  }
  function local(m){return new Promise((resolve,reject)=>{
    if(!validRequest(m.method,m.target)||typeof m.body!=='string'||m.body.length>400000){reject(Error('Invalid relay request'));return;}
    const payload=Buffer.from(m.body,'base64');
    const req=https.request({hostname:'localhost',family:4,port,method:m.method,path:m.target,agent,
      headers:{host:'localhost:'+port,origin:'https://localhost:'+port,'content-type':m.contentType==='application/json'?'application/json':'application/octet-stream',...(typeof m.authorization==='string'?{authorization:m.authorization}:{})},
      signal:AbortSignal.any([stopSignal.signal,AbortSignal.timeout(33000)])},async res=>{
        try{const body=await readLimited(res,16*1024*1024);resolve({requestId:m.requestId,status:res.statusCode,contentType:res.headers['content-type'],body:body.toString('base64')});}catch(e){reject(e);}
      });req.on('error',reject);req.end(payload);
  });}
  async function work(m){try{await call('/bridge/result',await local(m),20000);}catch{try{await call('/bridge/result',{requestId:m.requestId,status:502,contentType:'application/json',body:Buffer.from(JSON.stringify({error:'Host request failed'})).toString('base64')},5000);}catch{}}}
  (async()=>{while(!stopped){
    try{
      if(!id){const registration=await call('/register',{},15000);if(!/^\d{12}$/.test(registration.id))throw Error('Invalid Computer ID');id=registration.id;}
      if(inflight.size>=8){await Promise.race(inflight);continue;}
      const result=await call('/bridge/poll',{capacity:8-inflight.size});
      if(!online){online=true;onStatus(remote.origin+'/?host='+encodeURIComponent(id),id);}
      for(const m of result.requests||[]){if(inflight.size>=8)break;const p=work(m).finally(()=>inflight.delete(p));inflight.add(p);}
    }catch(e){if(stopped)break;if(automaticRegistration&&e.status===401)id='';online=false;onLost();onStatus(null,id);await new Promise(r=>setTimeout(r,2000));}
  }})().catch(()=>{onLost();});
  return ()=>{stopped=true;stopSignal.abort();agent.destroy();};
}

