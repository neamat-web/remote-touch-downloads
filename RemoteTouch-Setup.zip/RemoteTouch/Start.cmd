@echo off
cd /d "%~dp0"
if not exist runtime\node.exe (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Prepare-Runtime.ps1"
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
start "" "%~dp0RemoteTouch.exe"
