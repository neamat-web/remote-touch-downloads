import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {runRelay} from './server.mjs';

const origin=process.env.RT_RELAY_ORIGIN||process.env.RENDER_EXTERNAL_URL;
if(!origin||!origin.startsWith('https://')||new URL(origin).origin!==origin)throw Error('Set RT_RELAY_ORIGIN to the public HTTPS origin, or run on Render.');
const clientOrigins=(process.env.RT_CLIENT_ORIGINS||origin).split(',').map(x=>x.trim()).filter(Boolean);
if(clientOrigins.some(x=>!x.startsWith('https://')||new URL(x).origin!==x))throw Error('RT_CLIENT_ORIGINS must contain HTTPS origins only');
const maxDevices=Number(process.env.RT_MAX_DEVICES||1000);
if(!Number.isInteger(maxDevices)||maxDevices<1||maxDevices>10000)throw Error('RT_MAX_DEVICES must be an integer from 1 to 10000');
const configFile=process.env.RT_GENERATED_CONFIG||path.join(os.tmpdir(),'remote-touch-relay-config.json');
// Pilot limits deliberately group requests by proxy socket IP. Do not trust client-supplied headers.
const config={origin,clientOrigins,bindHost:'0.0.0.0',trustProxy:false,publicRegistration:true,registryPath:process.env.RT_REGISTRY_PATH||path.join(os.tmpdir(),'remote-touch-devices.json'),maxDevices,hosts:{}};
await fs.writeFile(configFile,JSON.stringify(config)+'\n',{mode:0o600});
await runRelay(configFile);
