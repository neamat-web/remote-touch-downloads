import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {digest,equal,Limiter} from '../server/security.mjs';
import {Registry} from './registry.mjs';
import {validRequest,readLimited} from './protocol.mjs';

export function createRelay({origin,clientOrigins=[],hosts={},webRoot,trustProxy=false,registry=null}){
  const site=new URL(origin);if(site.protocol!=='https:'||site.origin!==origin)throw Error('origin must be an HTTPS origin');
  const allowed=new Set([origin,...clientOrigins]);
  if([...allowed].some(x=>!x.startsWith('https://')||new URL(x).origin!==x))throw Error('Invalid browser origin');
  const devices=new Map(Object.entries(hosts).map(([id,h])=>{
    if(!/^[a-z0-9-]{6,64}$/.test(id)||! /^[a-f0-9]{64}$/.test(h.keyHash))throw Error('Invalid registered host');
    return[id,{keyHash:h.keyHash,queue:[],waiting:null,pending:new Map(),lastSeen:0}];
  }));
  const registrationIP=new Limiter(10,3600000),registrationGlobal=new Limiter(100,60000);
  const limit=new Limiter(500,1000),pairs=new Limiter(5,60000),globalPairs=new Limiter(20,60000);
  const assets=new Map([['/','index.html'],['/app.mjs','app.mjs'],['/geometry.mjs','geometry.mjs'],['/style.css','style.css']]);
  function json(res,status,obj){if(res.destroyed||res.writableEnded)return;res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(obj));}
  function fail(status,message){throw Object.assign(Error(message),{status});}
  function deliver(d){if(!d.waiting||!d.queue.length)return;const w=d.waiting;d.waiting=null;clearTimeout(w.timer);json(w.res,200,{requests:d.queue.splice(0,w.capacity)});}
  const server=http.createServer(async(req,res)=>{
    res.setHeader('cache-control','no-store');res.setHeader('x-content-type-options','nosniff');res.setHeader('referrer-policy','no-referrer');
    res.setHeader('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    try{
      const requestOrigin=req.headers.origin;
      if(req.headers.host!==site.host)fail(403,'Unrecognized host');
      if(requestOrigin&&!allowed.has(requestOrigin))fail(403,'Unrecognized browser origin');
      if(requestOrigin){res.setHeader('access-control-allow-origin',requestOrigin);res.setHeader('vary','Origin');}
      // Only enable behind the supplied Caddy configuration, on loopback.
      const ip=trustProxy?String(req.headers['x-rt-client-ip']||''):req.socket.remoteAddress;
      if(!ip||ip.length>64)fail(400,'Missing proxy address');
      if(!limit.allow(ip))fail(429,'Too many requests');
      const u=new URL(req.url,origin);
      if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-methods':'GET,POST,PUT,OPTIONS','access-control-allow-headers':'Authorization,Content-Type,X-RT-Host','access-control-max-age':'600'});res.end();return;}
      if(u.pathname==='/config.json'&&req.method==='GET'){json(res,200,{mode:'company',relayUrl:origin});return;}
      if(assets.has(u.pathname)&&req.method==='GET'){
        const name=assets.get(u.pathname);res.setHeader('content-type',name.endsWith('.css')?'text/css':name.endsWith('.mjs')?'text/javascript':'text/html; charset=utf-8');res.end(await fs.readFile(path.join(webRoot,name)));return;
      }
      if(u.pathname==='/register'){
        if(!registry)fail(404,'Public registration is not enabled');
        if(req.method!=='POST'||requestOrigin)fail(403,'Registration is only available to the Windows application');
        if(!registrationIP.allow(ip)||!registrationGlobal.allow('all'))fail(429,'Too many registrations. Try again later.');
        const auth=req.headers.authorization||'';
        if(!/^Bearer [A-Za-z0-9_-]{43}$/.test(auth))fail(401,'A device registration credential is required');
        await readLimited(req,1024);
        const entry=await registry.register(auth.slice(7));
        if(!devices.has(entry.id))devices.set(entry.id,{keyHash:entry.keyHash,queue:[],waiting:null,pending:new Map(),lastSeen:0});
        json(res,200,{id:entry.id});return;
      }
      const d=devices.get(req.headers['x-rt-host']);
      if(u.pathname.startsWith('/bridge/')){
        const auth=req.headers.authorization;
        if(req.method!=='POST'||!d||typeof auth!=='string'||!auth.startsWith('Bearer ')||auth.length>100||!equal(d.keyHash,digest(auth.slice(7))))fail(401,'Host authentication required');
        if(requestOrigin)fail(403,'Host endpoint does not accept browser requests');
        if(u.pathname==='/bridge/poll'){
          const poll=JSON.parse((await readLimited(req,1024)).toString()||'{}');const capacity=poll.capacity??8;if(!Number.isInteger(capacity)||capacity<1||capacity>8)fail(400,'Invalid capacity');d.lastSeen=Date.now();
          if(d.waiting)fail(409,'Host already polling');
          const w={res,timer:null,capacity};w.timer=setTimeout(()=>{if(d.waiting===w){d.waiting=null;json(res,200,{requests:[]});}},20000);d.waiting=w;
          res.on('close',()=>{if(d.waiting===w){d.waiting=null;clearTimeout(w.timer);}});deliver(d);return;
        }
        if(u.pathname==='/bridge/result'){
          const m=JSON.parse((await readLimited(req,23*1024*1024)).toString());const p=d.pending.get(m.requestId);
          if(!p)fail(404,'Request expired');
          if(!Number.isInteger(m.status)||m.status<200||m.status>599||typeof m.body!=='string'||m.body.length>23*1024*1024)fail(400,'Invalid host response');
          d.pending.delete(m.requestId);clearTimeout(p.timer);
          if(!p.res.destroyed){p.res.writeHead(m.status,{'content-type':['application/json','application/json; charset=utf-8','image/jpeg','application/octet-stream'].includes(m.contentType)?m.contentType:'application/octet-stream'});p.res.end(Buffer.from(m.body,'base64'));}
          json(res,200,{ok:true});return;
        }
        fail(404,'Route not found');
      }
      if(!validRequest(req.method,req.url))fail(404,'Route not found');
      if(u.pathname==='/api/pair'&&(!pairs.allow(ip)||!globalPairs.allow(req.headers['x-rt-host'])))fail(429,'Too many pairing attempts. Wait one minute.');
      if(!d||(!d.waiting&&Date.now()-d.lastSeen>25000))fail(503,'Computer is offline. Open Remote Touch on the computer and click Start.');
      if(d.pending.size>=8)fail(429,'Computer is busy. Try again.');
      if(u.pathname!=='/api/pair'&&!/^Bearer [A-Za-z0-9_-]{43}$/.test(req.headers.authorization||''))fail(401,'Pair with the computer first');
      const payload=await readLimited(req,300000);
      // Recheck after body read to prevent slow parallel requests bypassing capacity.
      if(d.pending.size>=8)fail(429,'Computer is busy');
      const requestId=randomUUID();const timer=setTimeout(()=>{d.pending.delete(requestId);d.queue=d.queue.filter(x=>x.requestId!==requestId);json(res,504,{error:'Computer did not respond. Try again.'});},34000);
      d.pending.set(requestId,{res,timer});res.on('close',()=>{clearTimeout(timer);d.pending.delete(requestId);d.queue=d.queue.filter(x=>x.requestId!==requestId);});
      d.queue.push({requestId,method:req.method,target:req.url,authorization:req.headers.authorization,contentType:req.headers['content-type'],body:payload.toString('base64')});deliver(d);
    }catch(e){if(!res.headersSent)json(res,e.status||400,{error:e.status?e.message:'Invalid request'});else res.destroy();}
  });
  server.requestTimeout=40000;server.headersTimeout=10000;server.maxConnections=250;
  server.on('clientError',(_,s)=>s.destroy());
  server.on('close',()=>{for(const d of devices.values()){if(d.waiting){clearTimeout(d.waiting.timer);d.waiting.res.destroy();}for(const p of d.pending.values()){clearTimeout(p.timer);p.res.destroy();}}});
  return server;
}
export async function runRelay(configFile=process.env.RT_RELAY_CONFIG||'relay-config.json'){
  const config=JSON.parse(await fs.readFile(configFile,'utf8'));
  const webRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../web');
  let registry=null;
  if(config.publicRegistration===true){
    if(!config.registryPath)throw Error('Public registration requires a registryPath');
    registry=await new Registry(config.registryPath,config.maxDevices||1000).load();
  }
  const server=createRelay({...config,hosts:{...(config.hosts||{}),...(registry?.enabledHosts()||{})},registry,webRoot,trustProxy:config.trustProxy!==false});
  const host=process.env.HOST||config.bindHost||'127.0.0.1';
  server.listen(Number(process.env.PORT||8080),host,()=>console.log(`Remote Touch relay listening on ${host}:${process.env.PORT||8080}.`));
  return server;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))await runRelay();
