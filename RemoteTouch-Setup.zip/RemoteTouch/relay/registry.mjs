import fs from 'node:fs/promises';
import path from 'node:path';
import {randomInt} from 'node:crypto';
import {digest} from '../server/security.mjs';

// Single-process registry for the pilot. Serialized writes prevent lost registrations.
// Store only secret hashes; never store raw host credentials or desktop contents.
export class Registry {
  constructor(file,maxDevices=1000){
    if(!Number.isInteger(maxDevices)||maxDevices<1||maxDevices>10000)throw Error('Registration capacity must be 1–10000');
    this.file=file;this.maxDevices=maxDevices;this.records={};this.writes=Promise.resolve();
  }
  async load(){
    try{this.records=JSON.parse(await fs.readFile(this.file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
    if(!this.records||Array.isArray(this.records)||typeof this.records!=='object'||Object.keys(this.records).length>this.maxDevices)throw Error('Invalid device registry');
    for(const [id,r] of Object.entries(this.records))if(!/^\d{12}$/.test(id)||!r||! /^[a-f0-9]{64}$/.test(r.keyHash)||typeof r.disabled!=='boolean')throw Error('Invalid registered device');
    return this;
  }
  async register(key){
    if(!/^[A-Za-z0-9_-]{43}$/.test(key))throw Object.assign(Error('Invalid registration credential'),{status:400});
    const task=this.writes.then(async()=>{
      const keyHash=digest(key),existing=Object.entries(this.records).find(([,r])=>r.keyHash===keyHash);
      if(existing){if(existing[1].disabled)throw Object.assign(Error('Device registration is disabled'),{status:403});return{id:existing[0],keyHash};}
      if(Object.keys(this.records).length>=this.maxDevices)throw Object.assign(Error('Service registration capacity reached. Contact support.'),{status:503});
      let id;do{id=String(randomInt(100000000000,1000000000000));}while(this.records[id]);
      const records={...this.records,[id]:{keyHash,createdAt:new Date().toISOString(),disabled:false}};
      await fs.mkdir(path.dirname(this.file),{recursive:true,mode:0o700});
      await fs.writeFile(this.file+'.tmp',JSON.stringify(records)+'\n',{mode:0o600});
      await fs.rename(this.file+'.tmp',this.file);this.records=records;return{id,keyHash};
    });
    this.writes=task.catch(()=>{});return task;
  }
  enabledHosts(){return Object.fromEntries(Object.entries(this.records).filter(([,r])=>!r.disabled).map(([id,r])=>[id,{keyHash:r.keyHash}]));}
}
