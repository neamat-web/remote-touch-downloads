export const routes=new Map([
  ['/api/pair',['POST']],['/api/heartbeat',['POST']],['/api/disconnect',['POST']],
  ['/api/release',['POST']],['/api/monitors',['GET']],['/api/frame',['GET']],
  ['/api/input',['POST']],['/api/clipboard',['GET','POST']],
  ['/api/files/upload',['POST']],['/api/files/download',['POST']],
  ['/api/files/cancel',['POST']],['/api/files/chunk',['GET','PUT']]
]);
export function validRequest(method,target){
  if(typeof target!=='string'||target.length>2048||!target.startsWith('/api/')||target.includes('#')||target.includes('\\'))return false;
  const u=new URL(target,'https://local.invalid');
  return routes.get(u.pathname)?.includes(method)===true;
}
export async function readLimited(stream,max){
  let n=0;const chunks=[];
  for await(const c of stream){n+=c.length;if(n>max)throw Object.assign(new Error('Payload too large'),{status:413});chunks.push(c);}
  return Buffer.concat(chunks);
}
